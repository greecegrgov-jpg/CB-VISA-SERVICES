const menuBtn = document.querySelector(".menu-btn");
const navWrap = document.querySelector(".nav-wrap");
const navLinks = document.querySelectorAll(".nav a");

menuBtn?.addEventListener("click", () => {
  navWrap.classList.toggle("menu-open");
});

navLinks.forEach(link => {
  link.addEventListener("click", () => navWrap.classList.remove("menu-open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

form?.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const name = data.get("name") || "there";
  formMessage.textContent = `Thank you, ${name}. Your enquiry has been prepared. Connect your WhatsApp/email backend here to receive submissions.`;
  form.reset();
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function (event) {
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});
