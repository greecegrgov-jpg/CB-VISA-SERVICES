const menuBtn = document.querySelector(".menu-btn");
const navWrap = document.querySelector(".nav-wrap");
const navLinks = document.querySelectorAll(".nav a");

menuBtn?.addEventListener("click", () => {
  navWrap.classList.toggle("menu-open");
});

navLinks.forEach(link => {
  link.addEventListener("click", () => navWrap.classList.remove("menu-open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

form?.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const name = data.get("name") || "there";
  const phone = data.get("phone") || "";
  const destination = data.get("destination") || "";
  const service = data.get("service") || "";
  const message = data.get("message") || "";
  const whatsappNumber = "923000000000"; // Replace with your real WhatsApp number.
  const text = `Hello Cross Border Visa Services,%0A%0AName: ${name}%0APhone: ${phone}%0ADestination: ${destination}%0AService: ${service}%0AMessage: ${message}`;
  formMessage.innerHTML = `Enquiry ready. <a href="https://wa.me/${whatsappNumber}?text=${text}" target="_blank" rel="noopener">Click here to send it on WhatsApp →</a>`;
  form.reset();
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function (event) {
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});
